package controller;

import Main.Main;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;
import utils.Utils;


import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class HomeScreenController implements Initializable {

    private static Inventory allInventory = Main.getAllInventory();
    private Alert alert;
    private Part part = null;
    private Product product = null;
    private FXMLLoader loader;

    @FXML
    private AnchorPane inventoryHomeScreenContainer;

    @FXML
    private MenuBar inventoryHomeScreenMainMenuBar;

    @FXML
    private MenuItem menuExitItem;

    @FXML
    private Label inventoryHomeScreenMainHeaderLbl;

    @FXML
    private Button inventoryHomeScreenExitBtn;

    @FXML
    private TextField inventoryHomeScreenPartSearchInput;

    @FXML
    private Button inventoryHomeScreenAddPartBtn;

    @FXML
    private Button inventoryHomeScreenModifyPartBtn;

    @FXML
    private Button inventoryHomeScreenDeleteBtn;

    @FXML
    private TableView<Part> inventoryHomeScreenPartsTable;

    @FXML
    private TableColumn<Part, Integer> inventoryHomeScreenPartIDColHeader;

    @FXML
    private TableColumn<Part, String> inventoryHomeScreenPartNameColHeader;

    @FXML
    private TableColumn<Part, Integer> inventoryHomeScreenPartCountColHeader;

    @FXML
    private TableColumn<Part, Double> inventoryHomeScreenPartPriceColHeader;

    @FXML
    private Button inventoryHomeScreenPartSearchBtn;

    @FXML
    private TextField inventoryHomeScreenProductSearchInput;

    @FXML
    private Button inventoryHomeScreenProductDeleteBtn;

    @FXML
    private Button inventoryHomeScreenProductModifyBtn;

    @FXML
    private Button inventoryHomeScreenAddProductBtn;

    @FXML
    private TableView<Product> inventoryHomeScreenProductsTable;

    @FXML
    private TableColumn<Product, Integer> inventoryHomeScreenProductIDColHeader;

    @FXML
    private TableColumn<Product, String> inventoryHomeScreenProductNameColHeader;

    @FXML
    private TableColumn<Product, Integer> inventoryHomeScreenProductCountColHeader;

    @FXML
    private TableColumn<Product, Double> inventoryHomeScreenProductPriceColHeader;

    @FXML
    private Button inventoryHomeScreenProductSearchBtn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setAllData();
    }

    public void setAllData() {

        inventoryHomeScreenPartsTable.setItems(allInventory.getAllParts());
        inventoryHomeScreenProductsTable.setItems(allInventory.getAllProducts());

        inventoryHomeScreenPartIDColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.id.toString()));
        inventoryHomeScreenPartNameColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.name.toString()));
        inventoryHomeScreenPartCountColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.stock.toString()));
        inventoryHomeScreenPartPriceColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.price.toString()));

        inventoryHomeScreenProductIDColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.id.toString()));
        inventoryHomeScreenProductNameColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.name.toString()));
        inventoryHomeScreenProductCountColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.stock.toString()));
        inventoryHomeScreenProductPriceColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.price.toString()));
    }

    @FXML
    void homeScreenAddPart(ActionEvent event) throws IOException {
        if (((Button) event.getSource()).getText().equalsIgnoreCase("ADD PART")) {
            navigateToScreen(event, Utils.VIEWS.PARTCONTROLLER.getValue());
        }
    }

    @FXML
    void homeScreenAddProduct(ActionEvent event) throws IOException {
        if (((Button) event.getSource()).getText().equalsIgnoreCase("ADD PRODUCT")) {
            navigateToScreen(event, Utils.VIEWS.PRODUCTCONTROLLER.getValue());
        }
    }

    @FXML
    void homeScreenExitBtn(ActionEvent event) {
        alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to exit?");
        Optional<ButtonType> confirmation = alert.showAndWait();
        if (confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
            System.exit(0);
        }
    }

    @FXML
    void homeScreenRemovePart(ActionEvent event) {
        try {
            int size = allInventory.getAllParts().size();
            alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to remove part?");
            Optional<ButtonType> confirmation = alert.showAndWait();
            if (confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
                Part local = allInventory.lookupPart(inventoryHomeScreenPartsTable.getSelectionModel().getSelectedItem().getId());
                allInventory.deletePart(local);
                if (size > allInventory.getAllParts().size()) {
                    alert = new Alert(Alert.AlertType.INFORMATION, "SUCCESSFULLY REMOVED " + local.getName());
                    alert.showAndWait();
                } else {
                    alert = new Alert(Alert.AlertType.ERROR, "No Selection Found!. Cannot Delete.");
                    alert.showAndWait();
                }
            }
            inventoryHomeScreenPartsTable.getSelectionModel().clearSelection();
        } catch (NullPointerException e) {
        }
    }

    @FXML
    void homeScreenRemoveProduct(ActionEvent event) {
        try {
            int size = allInventory.getAllProducts().size();
            alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to remove product?");
            Optional<ButtonType> confirmation = alert.showAndWait();
            if (confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
                Product local = allInventory.lookupProduct(inventoryHomeScreenProductsTable.getSelectionModel().getSelectedItem().getId());
                allInventory.deleteProduct(local);
                if (size > allInventory.getAllProducts().size()) {
                    alert = new Alert(Alert.AlertType.INFORMATION, "SUCCESSFULLY REMOVED " + local.getName());
                    alert.showAndWait();
                } else {
                    alert = new Alert(Alert.AlertType.ERROR, "No Selection Found!. Cannot Delete.");
                    alert.showAndWait();
                }
            }
            inventoryHomeScreenProductsTable.getSelectionModel().clearSelection();
        } catch (NullPointerException e) {
        }
    }

    @FXML
    void homeScreenSearchPartBtn(ActionEvent event) {
        if (((Button) event.getSource()).getText().equalsIgnoreCase("Search Part")) {
            if (inventoryHomeScreenPartSearchInput.getText().trim().isBlank() || inventoryHomeScreenPartSearchInput.getText().trim().isEmpty()
                    || allInventory.lookupPart(inventoryHomeScreenPartSearchInput.getText()).size() == 0) {
                alert = new Alert(Alert.AlertType.ERROR, "Could not any results! Please Try Again!");
                return;
            }
        }
    }

    @FXML
    public void searchPartWhileOnKey(KeyEvent keyEvent) {
        ObservableList<Part> partsFound = allInventory.lookupPart(inventoryHomeScreenPartSearchInput.getText());
        inventoryHomeScreenPartsTable.setItems(partsFound);
        if (partsFound.size() == 1) {
            inventoryHomeScreenPartsTable.getSelectionModel().select(partsFound.get(0));
        } else if (partsFound.size() == 0) {
        } else {
            inventoryHomeScreenPartsTable.getSelectionModel().clearSelection();
        }
    }

    @FXML
    public void searchProductWhileOnKey(KeyEvent keyEvent) {
        ObservableList<Product> productsFound = allInventory.lookupProduct(inventoryHomeScreenProductSearchInput.getText());
        inventoryHomeScreenProductsTable.setItems(productsFound);
        if (productsFound.size() == 1) {
            inventoryHomeScreenProductsTable.getSelectionModel().select(productsFound.get(0));
        } else if (productsFound.size() == 0) {
        } else {
            inventoryHomeScreenProductsTable.getSelectionModel().clearSelection();
        }
    }

    @FXML
    void homeScreenSearchProductBtn(ActionEvent event) {
        if (((Button) event.getSource()).getText().equalsIgnoreCase("Search Product")) {
            if (inventoryHomeScreenProductSearchInput.getText().isBlank() || inventoryHomeScreenProductSearchInput.getText().isEmpty()
                    || allInventory.lookupProduct(inventoryHomeScreenProductSearchInput.getText()).size() == 0) {
                alert = new Alert(Alert.AlertType.ERROR, "Could not any results! Please Try Again!");
                return;
            }
        }
    }

    @FXML
    void homeScreenUpdatePart(ActionEvent event) throws IOException {
        if (((Button) event.getSource()).getText().equalsIgnoreCase("MODIFY PART")) {
            if (inventoryHomeScreenPartsTable.getSelectionModel().getSelectedItem() == null) {
                alert = new Alert(Alert.AlertType.ERROR, "Please Select Part to Modify.");
                alert.showAndWait();
                return;
            }
            int index = inventoryHomeScreenPartsTable.getSelectionModel().getSelectedItem().getId();
            loader = new FXMLLoader();
            loader.setLocation(getClass().getResource(Utils.VIEWS.UPDATEPARTCONTROLLER.getValue()));
            loader.load();
            UpdatePartController controller = loader.getController();
            controller.initializeInputs(index);
            navigateToScreen(event, null);
        }
    }

    @FXML
    void homeScreenUpdateProduct(ActionEvent event) throws IOException {
        if (((Button) event.getSource()).getText().equalsIgnoreCase("MODIFY PRODUCT")) {
            if (inventoryHomeScreenProductsTable.getSelectionModel().getSelectedItem() == null) {
                alert = new Alert(Alert.AlertType.ERROR, "Please Select Product to Modify.");
                alert.showAndWait();
                return;
            }
            int index = inventoryHomeScreenProductsTable.getSelectionModel().getSelectedItem().getId();
            loader = new FXMLLoader();
            loader.setLocation(getClass().getResource(Utils.VIEWS.UPDATEPRODUCTCONTROLLER.getValue()));
            loader.load();
            UpdateProductController controller = loader.getController();
            controller.initializeInputs(index);
            navigateToScreen(event, null);
        }
    }


    private void navigateToScreen(ActionEvent event, String source) throws IOException {
        if (source == null) {
            navigateToScreenWithParam(event);
            return;
        }
        Stage page = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource(source));
        page.setScene(new Scene(root));
        page.show();
    }

    private void navigateToScreenWithParam(ActionEvent event) {
        Stage page = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = loader.getRoot();
        page.setScene(new Scene(root));
        page.show();
    }

    public static Inventory getAllInventory() {
        return allInventory;
    }


}
