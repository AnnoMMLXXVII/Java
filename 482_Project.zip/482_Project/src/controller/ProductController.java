package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Inventory;
import model.Part;
import model.Product;
import utils.Utils;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class ProductController implements Initializable {

    private Inventory allInventory = HomeScreenController.getAllInventory();
    private ObservableList<Part> associationList = FXCollections.observableArrayList();
    private Inventory allPartsInventory = HomeScreenController.getAllInventory();
    private Alert alert;

    @FXML
    private TextField addProductIdInput;

    @FXML
    private TextField addProductNameInput;

    @FXML
    private TextField addProductStockInput;

    @FXML
    private TextField addProductPriceInput;

    @FXML
    private TextField addProductMaxInput;

    @FXML
    private TextField addProductMinInput;

    @FXML
    private Button addProductSearchBtn;

    @FXML
    private TextField addProductSearchInput;

    @FXML
    private TableView<Part> addProductPartSearchTableView;

    @FXML
    private TableColumn<Part, Integer> addProductPartIdColHeader;

    @FXML
    private TableColumn<Part, String> addProductPartNameColHeader;

    @FXML
    private TableColumn<Part, Integer> addProductPartStockColHeader;

    @FXML
    private TableColumn<Part, Double> addProductPartPriceColHeader;

    @FXML
    private TableView<Part> addProductAssociationTable;

    @FXML
    private TableColumn<Part, Integer> addProductAssociationPartIdColHeader;

    @FXML
    private TableColumn<Part, String> addProductAssociationPartNameColHeader;

    @FXML
    private TableColumn<Part, Integer> addProductAssociationPartStockColHeader;

    @FXML
    private TableColumn<Part, Double> addProductAssociationPartPriceColHeader;

    @FXML
    private Button addProductSaveBtn;

    @FXML
    private Button addProductsRemoveAssociationBtn;

    private Product newProduct;

    @FXML
    void addToAssociation(ActionEvent event) {
        try {
            int size = associationList.size();
            alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to move the part?");
            Optional<ButtonType> confirmation = alert.showAndWait();
            if (confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
                Part local = allInventory.lookupPart(addProductPartSearchTableView.getSelectionModel().getSelectedItem().getId());
                associationList.add(local);
                if (size < associationList.size()) {
                    alert = new Alert(Alert.AlertType.INFORMATION, "Successfully Created An Association with " + local.getName());
                    alert.showAndWait();
                }
            }
            addProductPartSearchTableView.getSelectionModel().clearSelection();
            addProductAssociationTable.getSelectionModel().clearSelection();
        } catch (NullPointerException e) {
        }
    }

    @FXML
    void cancelAddProduct(ActionEvent event) throws IOException {
        alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to cancel?");
        Optional<ButtonType> confirmation = alert.showAndWait();
        if (confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
            Utils.navigateBackToTheHomeScreen(event);
        }
    }

    @FXML
    void saveAddProduct(ActionEvent event) throws IOException {
        int size = HomeScreenController.getAllInventory().getAllProducts().size();
        if (Utils.validate(addProductNameInput, addProductStockInput, addProductPriceInput, addProductMaxInput, addProductMinInput)) {
            addNewProduct();
            if (HomeScreenController.getAllInventory().getAllParts().size() > size) {
                Utils.navigateBackToTheHomeScreen(event);
            }
        } else {
            alert = new Alert(Alert.AlertType.ERROR, String.valueOf(Utils.validationMessage));
            Optional<ButtonType> confirmation = alert.showAndWait();
            if (confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
                alert.close();
            }
        }
        addProductPartSearchTableView.getSelectionModel().clearSelection();
        addProductAssociationTable.getSelectionModel().clearSelection();
    }

    @FXML
    void searchForPart(ActionEvent event) {
        ObservableList<Part> parts = allInventory.lookupPart(addProductSearchInput.getText());
        addProductPartSearchTableView.setItems(parts);
        if (parts.size() == 1) {
            addProductPartSearchTableView.getSelectionModel().select(parts.get(0));
        } else if (parts.size() == 0) {
        } else {
            addProductPartSearchTableView.getSelectionModel().clearSelection();
        }
        addProductPartSearchTableView.getSelectionModel().clearSelection();
        addProductAssociationTable.getSelectionModel().clearSelection();
    }

    @FXML
    public void removeAssociation(ActionEvent actionEvent) {
        if (associationList.size() == 0) {
            return;
        }
        try {
            int size = associationList.size();
            alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to Remove Association?");
            Optional<ButtonType> confirmation = alert.showAndWait();
            if (confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
                Part local = searchForExistingAssociatedPart();
                if (local != null) {
                    associationList.remove(local);
                    if (size > associationList.size()) {
                        alert = new Alert(Alert.AlertType.INFORMATION, "Successfully Removed Association " + local.getName());
                        alert.showAndWait();
                    }
                } else {
                    alert = new Alert(Alert.AlertType.ERROR, "Could NOT Remove Association: Part Not Found!");
                    alert.showAndWait();
                }
            }
            addProductPartSearchTableView.getSelectionModel().clearSelection();
            addProductAssociationTable.getSelectionModel().clearSelection();
        } catch (NullPointerException e) {
        }
    }

    private void addNewProduct() {
        newProduct = new Product(HomeScreenController.getAllInventory().getAllParts().size(), addProductNameInput.getText(),
                Utils.getAsDouble(addProductPriceInput.getText()), Utils.getAsInteger(addProductStockInput.getText()),
                Utils.getAsInteger(addProductMaxInput.getText()), Utils.getAsInteger(addProductMinInput.getText()));
        HomeScreenController.getAllInventory().addProduct(newProduct);
        addProductPartSearchTableView.getSelectionModel().clearSelection();
        addProductAssociationTable.getSelectionModel().clearSelection();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        addProductPartSearchTableView.setItems(allInventory.getAllParts());
        addProductAssociationTable.setItems(associationList);

        addProductPartIdColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.id.toString()));
        addProductPartNameColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.name.toString()));
        addProductPartStockColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.stock.toString()));
        addProductPartPriceColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.price.toString()));

        addProductAssociationPartIdColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.id.toString()));
        addProductAssociationPartNameColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.name.toString()));
        addProductAssociationPartStockColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.stock.toString()));
        addProductAssociationPartPriceColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.price.toString()));
    }

    private Part searchForExistingAssociatedPart() {
        for (Part p : associationList) {
            if (p.getId() == (addProductAssociationTable.getSelectionModel().getSelectedItem().getId())) {
                return p;
            }
        }
        return null;
    }
}
