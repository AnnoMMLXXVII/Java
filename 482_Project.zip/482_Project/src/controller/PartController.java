package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.InHouse;
import model.Outsourced;
import utils.Utils;
import model.Part;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class PartController implements Initializable {

    private Alert alert;

    @FXML
    private RadioButton addPartInHouseRadioBtn;

    @FXML
    private ToggleGroup toggleGroup;

    @FXML
    private RadioButton addPartOutSourcedRadioBtn;

    @FXML
    private TextField addPartIdInput;

    @FXML
    private TextField addPartNameInput;

    @FXML
    private TextField addPartStockInput;

    @FXML
    private TextField addPartPriceInput;

    @FXML
    private TextField addPartMaxInput;

    @FXML
    private TextField addPartCompanyMachineInput;

    @FXML
    private TextField addPartMinInput;

    @FXML
    private Label addPartCompanyMachineLbl;

    @FXML
    private Button addPartCancelBtn;

    @FXML
    private Button addPartSaveBtn;

    private boolean isInHouse = true;
    private Part newPart = null;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        addPartInHouseRadioBtn.setSelected(true);
        isInHouse = true;
        addPartCompanyMachineLbl.setText("Machine Id");
    }

    @FXML
    void cancelAddPart(ActionEvent event) throws IOException {
        alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to cancel?");
        Optional<ButtonType> confirmation = alert.showAndWait();
        if(confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
            Utils.navigateBackToTheHomeScreen(event);
        }
    }

    @FXML
    void saveAddPart(ActionEvent event) throws IOException {
        int size = HomeScreenController.getAllInventory().getAllParts().size();
        if(Utils.validate(addPartNameInput, addPartStockInput, addPartPriceInput, addPartMaxInput, addPartMinInput)
                && Utils.validateMachineIdOrCompanyName(addPartCompanyMachineInput, addPartInHouseRadioBtn.isSelected(), addPartOutSourcedRadioBtn.isSelected())) {
            addNewPart(isInHouse);
            if(HomeScreenController.getAllInventory().getAllParts().size() > size) {
                Utils.navigateBackToTheHomeScreen(event);
            }
        }
        else {
            alert = new Alert(Alert.AlertType.ERROR, String.valueOf(Utils.validationMessage));
            Optional<ButtonType> confirmation = alert.showAndWait();
            if(confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
                alert.close();
            }
        }
    }

    @FXML
    void selectInHouse(MouseEvent event) {
        addPartCompanyMachineLbl.setText("Machine Id");
        isInHouse = true;
    }

    @FXML
    void selectOutSourced(MouseEvent event) {
        addPartCompanyMachineLbl.setText("Company Name");
        isInHouse = false;
    }


    private void addNewPart(boolean isInHouse) {
        newPart = (isInHouse) ?
                new InHouse(HomeScreenController.getAllInventory().getAllParts().size(), addPartNameInput.getText(), Utils.getAsDouble(addPartPriceInput.getText()), Utils.getAsInteger(addPartStockInput.getText()),
                Utils.getAsInteger(addPartMaxInput.getText()), Utils.getAsInteger(addPartMinInput.getText()), Utils.getAsInteger(addPartCompanyMachineInput.getText()))
            :
                new Outsourced(HomeScreenController.getAllInventory().getAllParts().size(), addPartNameInput.getText(), Utils.getAsDouble(addPartPriceInput.getText()), Utils.getAsInteger(addPartStockInput.getText()),
                Utils.getAsInteger(addPartMaxInput.getText()), Utils.getAsInteger(addPartMinInput.getText()), addPartCompanyMachineInput.getText());
        HomeScreenController.getAllInventory().addPart(newPart);
    }



}

