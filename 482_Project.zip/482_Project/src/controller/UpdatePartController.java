package controller;

import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import model.InHouse;
import model.Outsourced;
import model.Part;
import utils.Utils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.util.Comparator;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class UpdatePartController {

    private Alert alert;
    private int id;
    private boolean isInHouse;
    @FXML
    private RadioButton updatePartInHouseRadioBtn;

    @FXML
    private ToggleGroup source;

    @FXML
    private RadioButton updatePartOutSourcedRadioBtn;

    @FXML
    private TextField updatePartIdInput;

    @FXML
    private TextField updatePartNameInput;

    @FXML
    private TextField updatePartStockInput;

    @FXML
    private TextField updatePartPriceInput;

    @FXML
    private TextField updatePartMaxQtyInput;

    @FXML
    private TextField updatePartCompanyMachineInput;

    @FXML
    private TextField updatePartMinQtyInput;

    @FXML
    private Label updatePartCompanyMachineLbl;

    @FXML
    private Button updatePartCancelBtn;

    @FXML
    private Button updatePartSaveBtn;

    @FXML
    void cancelModifyPart(ActionEvent event) throws IOException {
        alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to cancel?");
        Optional<ButtonType> confirmation = alert.showAndWait();
        if (confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
            Utils.navigateBackToTheHomeScreen(event);
        }
    }

    @FXML
    void saveModifyPart(ActionEvent event) throws IOException {
        Utils.setAction("Modify");
        if (Utils.validate(updatePartNameInput, updatePartStockInput, updatePartPriceInput,
                updatePartMaxQtyInput, updatePartMinQtyInput)
                && Utils.validateMachineIdOrCompanyName(updatePartCompanyMachineInput,
                updatePartInHouseRadioBtn.isSelected(), updatePartOutSourcedRadioBtn.isSelected())) {
            if (isInHouse) {
                updateInHouse();
            } else {
                updateOutSourced();
            }
            alert = new Alert(Alert.AlertType.INFORMATION, "SUCCESSFULLY UPDATED!");
            alert.showAndWait();
            Utils.navigateBackToTheHomeScreen(event);
        } else {
            alert = new Alert(Alert.AlertType.ERROR, Utils.validationMessage.toString());
            alert.showAndWait();
        }
    }

    @FXML
    void selectInHouse(ActionEvent event) {
        updatePartCompanyMachineInput.setText("Machine Id");
    }

    @FXML
    void selectOutSourced(ActionEvent event) {
        updatePartCompanyMachineInput.setText("Company Name");
    }

    public void initializeInputs(int id) {
        this.id = id;
        Part part = null;
        for (Part p : HomeScreenController.getAllInventory().getAllParts()) {
            if (p.getId() == id) {
                part = p;
                break;
            }
        }
        updatePartIdInput.setText(String.valueOf(part.getId()));
        updatePartNameInput.setText(part.getName());
        updatePartStockInput.setText(String.valueOf(part.getStock()));
        updatePartPriceInput.setText(String.format("%,.2f", part.getPrice()));
        updatePartMaxQtyInput.setText(String.valueOf(part.getMax()));
        updatePartMinQtyInput.setText(String.valueOf(part.getMin()));
        initializePolymorphicLogic(part);
    }

    private void initializePolymorphicLogic(Part part) {
        isInHouse = (part instanceof InHouse);
        updatePartCompanyMachineLbl.setText(isInHouse ? "Machine Id" : "Company Name");
        updatePartInHouseRadioBtn.setSelected(isInHouse ? true : false);
        updatePartOutSourcedRadioBtn.setSelected(isInHouse ? false : true);
        updatePartCompanyMachineInput.setText(isInHouse ? (String.valueOf(((InHouse) part).getMachineId())) : ((Outsourced) part).getCompanyName());
    }

    private void updateInHouse() {
        HomeScreenController.getAllInventory().updatePart(
                this.id,
                new InHouse(
                        this.id,
                        updatePartNameInput.getText(),
                        Utils.getAsDouble(updatePartPriceInput.getText()),
                        Utils.getAsInteger(updatePartStockInput.getText()),
                        Utils.getAsInteger(updatePartMinQtyInput.getText()),
                        Utils.getAsInteger(updatePartMaxQtyInput.getText()),
                        Utils.getAsInteger(updatePartCompanyMachineInput.getText())
                )
        );
    }

    private void updateOutSourced() {
        HomeScreenController.getAllInventory().updatePart(
                this.id,
                new Outsourced(
                        this.id,
                        updatePartNameInput.getText(),
                        Utils.getAsDouble(updatePartPriceInput.getText()),
                        Utils.getAsInteger(updatePartStockInput.getText()),
                        Utils.getAsInteger(updatePartMinQtyInput.getText()),
                        Utils.getAsInteger(updatePartMaxQtyInput.getText()),
                        updatePartCompanyMachineInput.getText()
                )
        );
    }

}
