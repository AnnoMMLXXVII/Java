package controller;

import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import model.Inventory;
import model.Part;
import model.Product;
import utils.Utils;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class UpdateProductController implements Initializable {

    private Alert alert;
    private ObservableList<Part> associationList = FXCollections.observableArrayList();
    private Inventory allPartsInventory = HomeScreenController.getAllInventory();
    private Product newProduct;
    private int id;
    @FXML
    private TextField updateProductIdInput;

    @FXML
    private TextField updateProductNameInput;

    @FXML
    private TextField updateProductStockInput;

    @FXML
    private TextField updateProductPriceInput;

    @FXML
    private TextField updateProductMaxInput;

    @FXML
    private TextField updateProductMinInput;

    @FXML
    private Button updateProductSearchBtn;

    @FXML
    private TextField updateProductSearchBarInput;

    @FXML
    private TableView<Part> updateProductPartSearchTable;

    @FXML
    private TableColumn<Part, Integer> updateProductPartIDColHeader;

    @FXML
    private TableColumn<Part, String> updateProductPartNameColHeader;

    @FXML
    private TableColumn<Part, Integer> updateProductPartCountColHeader;

    @FXML
    private TableColumn<Part, Double> updateProductPartPriceColHeader;

    @FXML
    private Button updateProductAddBtn;

    @FXML
    private Button updateProductDeleteBtn;

    @FXML
    private Button updateProductCancelBtn;

    @FXML
    private TableView<Part> updateProductAssociationPartTable;

    @FXML
    private TableColumn<Part, Integer> updateProductAssociationPartIDColHeader;

    @FXML
    private TableColumn<Part, String> updateProductAssociationPartNameColHeader;

    @FXML
    private TableColumn<Part, Integer> updateProductAssociationPartCountColHeader;

    @FXML
    private TableColumn<Part, Double> updateProductAssociationPartPriceColHeader;

    @FXML
    private Button updateProductUpdateBtn;

    @FXML
    void cancelProductOnUpdateScreen(ActionEvent event) throws IOException {
        alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to cancel?");
        Optional<ButtonType> confirmation = alert.showAndWait();
        if (confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
            Utils.navigateBackToTheHomeScreen(event);
        }
    }

    @FXML
    void removeAssociationPartOnUpdateScreen(ActionEvent event) {
        if (associationList.size() == 0) {
            return;
        }
        try {
            int size = associationList.size();
            alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to Remove Association?");
            Optional<ButtonType> confirmation = alert.showAndWait();
            if (confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
                Part local = searchForExistingAssociatedPart();
                if (local != null) {
                    associationList.remove(local);
                    if (size > associationList.size()) {
                        alert = new Alert(Alert.AlertType.INFORMATION, "Successfully Removed Association " + local.getName());
                        alert.showAndWait();
                    }
                } else {
                    alert = new Alert(Alert.AlertType.ERROR, "Could NOT Remove Association: Part Not Found!");
                    alert.showAndWait();
                }
            }
            updateProductPartSearchTable.getSelectionModel().clearSelection();
            updateProductAssociationPartTable.getSelectionModel().clearSelection();
        } catch (NullPointerException e) {
        }
    }

    @FXML
    void addPartToAssociationOnUpdateScreen(ActionEvent event) {
        try {
            int size = associationList.size();
            alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to move the part?");
            Optional<ButtonType> confirmation = alert.showAndWait();
            if (confirmation.isPresent() && confirmation.get() == ButtonType.OK) {
                Part local = HomeScreenController.getAllInventory().lookupPart(updateProductPartSearchTable.getSelectionModel().getSelectedItem().getId());
                associationList.add(local);
                if (size < associationList.size()) {
                    alert = new Alert(Alert.AlertType.INFORMATION, "Successfully Created An Association with " + local.getName());
                    alert.showAndWait();
                }
            }
            updateProductPartSearchTable.getSelectionModel().clearSelection();
            updateProductAssociationPartTable.getSelectionModel().clearSelection();
        } catch (NullPointerException e) {
        }
    }

    @FXML
    void searchProductOnUpdateScreen(ActionEvent event) {
        ObservableList<Part> parts = HomeScreenController.getAllInventory().lookupPart(updateProductSearchBarInput.getText());
        updateProductPartSearchTable.setItems(parts);
        if (parts.size() == 1) {
            updateProductPartSearchTable.getSelectionModel().select(parts.get(0));
        } else if (parts.size() == 0) {
        } else {
            updateProductPartSearchTable.getSelectionModel().clearSelection();
        }
        updateProductPartSearchTable.getSelectionModel().clearSelection();
        updateProductAssociationPartTable.getSelectionModel().clearSelection();
    }

    @FXML
    void updateProductOnUpdateScreen(ActionEvent event) throws IOException {
        Utils.setAction("Modify");
        if (Utils.validate(updateProductIdInput, updateProductStockInput, updateProductStockInput,
                updateProductMaxInput, updateProductMinInput)) {
            updateProduct();
            alert = new Alert(Alert.AlertType.INFORMATION, "SUCCESSFULLY UPDATED!");
            alert.showAndWait();
            Utils.navigateBackToTheHomeScreen(event);
        } else {
            alert = new Alert(Alert.AlertType.ERROR, Utils.validationMessage.toString());
            alert.showAndWait();
        }
    }

    public void initializeInputs(int id) {
        this.id = id;
        Product prod = null;
        for (Product p : HomeScreenController.getAllInventory().getAllProducts()) {
            if (p.getId() == id) {
                prod = p;
                break;
            }
        }
        updateProductIdInput.setText(String.valueOf(prod.getId()));
        updateProductNameInput.setText(prod.getName());
        updateProductStockInput.setText(String.valueOf(prod.getStock()));
        updateProductPriceInput.setText(String.format("%,.2f", prod.getPrice()));
        updateProductMaxInput.setText(String.valueOf(prod.getMax()));
        updateProductMinInput.setText(String.valueOf(prod.getMin()));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        updateProductPartSearchTable.setItems(HomeScreenController.getAllInventory().getAllParts());
        updateProductAssociationPartTable.setItems(associationList);

        updateProductPartIDColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.id.toString()));
        updateProductPartNameColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.name.toString()));
        updateProductPartCountColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.stock.toString()));
        updateProductPartPriceColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.price.toString()));

        updateProductAssociationPartIDColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.id.toString()));
        updateProductAssociationPartNameColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.name.toString()));
        updateProductAssociationPartCountColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.stock.toString()));
        updateProductAssociationPartPriceColHeader.setCellValueFactory(new PropertyValueFactory<>(Utils.PROPERTY.price.toString()));
    }

    private void updateProduct() {
        newProduct = new Product(this.id, updateProductNameInput.getText(),
                Utils.getAsDouble(updateProductPriceInput.getText()), Utils.getAsInteger(updateProductStockInput.getText()),
                Utils.getAsInteger(updateProductMaxInput.getText()), Utils.getAsInteger(updateProductMinInput.getText()));
        HomeScreenController.getAllInventory().addProduct(newProduct);
        updateProductPartSearchTable.getSelectionModel().clearSelection();
        updateProductAssociationPartTable.getSelectionModel().clearSelection();
    }

    private Part searchForExistingAssociatedPart() {
        for (Part p : associationList) {
            if (p.getId() == (updateProductAssociationPartTable.getSelectionModel().getSelectedItem().getId())) {
                return p;
            }
        }
        return null;
    }
}


