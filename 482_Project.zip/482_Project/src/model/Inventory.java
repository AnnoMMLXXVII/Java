package model;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import utils.Utils;

import java.util.*;
import java.util.stream.Collectors;

public class Inventory {
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();

    public void addPart(Part newPart){
        allParts.add(newPart);
    }

    public void addProduct(Product newProduct){
        allProducts.add(newProduct);
    }

    public Part lookupPart(int partId){
        Optional<Part> foundPart = allParts.stream().filter(it -> it.getId() == partId).findFirst();
        System.out.println(foundPart.get());
        return foundPart.get();
    }

    public Product lookupProduct(int productId){
        Optional<Product> foundProducts = allProducts.stream().filter(it -> it.getId() == productId).findFirst();
        System.out.println(foundProducts.get());
        return foundProducts.get();
    }

    public ObservableList<Part> lookupPart(String partName){
        ObservableList<Part> partsFound = FXCollections.observableArrayList();
        for (Part part : allParts) {
            if (part.getName().startsWith(partName)) {
                partsFound.add(part);
            }
            try {
                if (part.getId() == Integer.parseInt(partName)) {
                    partsFound.add(part);
                }
            }
            catch (Exception e) {
            }
        }
        return partsFound;

    }

    public ObservableList<Product> lookupProduct(String productName){
        ObservableList<Product> productsFound = FXCollections.observableArrayList();
        for (Product product : allProducts) {
            if (product.getName().startsWith(productName)) {
                productsFound.add(product);
            }
            try {
                if (product.getId() == Integer.parseInt(productName)) {
                    productsFound.add(product);
                }
            }
            catch (Exception e) {
            }
        }
        return productsFound;
    }

    public void updatePart(int index, Part updatedPart){
        allParts.set(index, updatedPart);
    }

    public void updateProduct(int index, Product updatedProduct){
        allProducts.set(index, updatedProduct);
    }

    public boolean deleteProduct(Product oldProduct){
        return allProducts.remove(oldProduct);
    }

    public boolean deletePart(Part oldPart){
        return allParts.remove(oldPart);
    }

    public ObservableList<Part> getAllParts(){
        return allParts;
    }

    public ObservableList<Product> getAllProducts(){
        return allProducts;
    }

}
