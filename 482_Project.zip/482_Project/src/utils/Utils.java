package utils;

import controller.HomeScreenController;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import model.Part;
import model.Product;

import java.io.IOException;
import java.net.URL;

public class Utils {

    public static final String COL_NAME = "Name";
    public static final String COL_PRICE = "Price";
    public static final String COL_INV = "Inventory";
    public static final String COL_MIN = "Min";
    public static final String COL_MAX = "Max";
    public static final String COL_MACHINEID = "Machine Id";
    public static final String COL_COMPANYNAME = "Company Name";

    private static String action;
    private static boolean isValid = false;
    private static double newPrice;
    private static int newStock;
    private static int newMax;
    private static int newMin;
    private static String errors = "";
    public static StringBuilder validationMessage = new StringBuilder();

    public static int getAsInteger(String integerString) {
        return Integer.parseInt(integerString);
    }

    public static double getAsDouble(String doubleString) {
        return Double.parseDouble(doubleString);
    }

    public static String getErrorMesage() {
        return errors;
    }

    public static void clearErrorMessageText() {
        errors = "";
    }

    public static boolean validateNewPart(Part part) {
        if(part == null) {
            return isValid;
        }
        if(validateName(part.getName()) &&
                validateDoubleField(part.getPrice()+"", "Price") &&
                validateIntegerField(part.getStock()+"", "Stock") &&
                validateIntegerField(part.getMin()+"", "Min") &&
                validateIntegerField(part.getMax()+"", "Max")) {
            isValid = true;
        }
        return isValid;
    }

    public static boolean validateName(String name) {
        if(name == null) {
            errors = errors + ("Name field is null\n");
            return false;
        }
        if(name.isBlank() || name.isEmpty() || name.equals("")) {
            errors =  errors + ("Name field cannot be Empty or Blank!\n");
            return false;
        }
        return true;
    }

    public static boolean validateDoubleField(String doubleCol, String columnName) {
        if(doubleCol.isEmpty() || doubleCol.isBlank()) {
            errors += (columnName + " field cannot be Empty or Blank\n");
            return false;
        }
        if(getAsDouble(doubleCol) < 0.00) {
            errors += (columnName + " field cannot be less than Zero!\n");
            return false;
        }
        return true;
    }

    public static boolean validateIntegerField(String integerCol, String columnName) {
        if (integerCol.isEmpty() || integerCol.isBlank()) {
            errors = errors +(columnName + " field cannot be Empty or Blank\n");
            return false;
        }
        if (getAsInteger(integerCol) < 0) {
            errors = errors + (columnName + " field cannot be less than Zero!\n");
            return false;
        }
        return true;
    }

    public enum VIEWS {
        MAINCONTROLLER("/view/HomeScreenController.fxml"), PRODUCTCONTROLLER("/view/ProductController.fxml"), PARTCONTROLLER("/view/PartController.fxml"),
        UPDATEPRODUCTCONTROLLER("/view/UpdateProductController.fxml"), UPDATEPARTCONTROLLER("/view/UpdatePartController.fxml")
        ;
        private String value;
        VIEWS(String value) {
            this.value = value;
        }
        public String getValue(){
            return value;
        }
    }

    public enum PROPERTY {
        id, name, stock, price;
    }

    public static Part searchPart(ObservableList<Part> list, int key) {
        int idx = binarySearchPart(list, key);
        return (idx == -1) ? null : list.get(idx);
    }

    public static Part searchPart(ObservableList<Part> list, String key) {
        int idx = binarySearchPart(list, key);
        return (idx == -1) ? null : list.get(idx);
    }

    private static int binarySearchPart(ObservableList<Part> list, String partName) {
        int low = 0;
        int high = list.size() - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            if ((list.get(mid).getName().compareTo(partName)) == 0) {
                return mid;
            }
            if ((list.get(mid).getName().compareTo(partName)) < 0) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }
        return -1;
    }


    private static int binarySearchPart(ObservableList<Part> list, int partId) {
        int low = 0;
        int high = list.size() - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            if ((list.get(mid).getId() - partId) == 0) {
                return mid;
            }
            if ((list.get(mid).getId() - partId) < 0) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }
        return -1;
    }

    public Product searchProduct(ObservableList<Product> list, int key) {
        int idx = binarySearchProduct(list, key);
        return (idx == -1) ? null : list.get(idx);
    }

    private int binarySearchProduct(ObservableList<Product> list, int partId) {
        int low = 0;
        int high = list.size() - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            if ((list.get(mid).getId() - partId) == 0) {
                return mid;
            }
            if ((list.get(mid).getId() - partId) < 0) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }
        return -1;
    }

    public static void navigateBackToTheHomeScreen(ActionEvent event) throws IOException {
        URL resourceURL = new HomeScreenController().getClass().getResource(Utils.VIEWS.MAINCONTROLLER.getValue());
        Stage page = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = FXMLLoader.load(resourceURL);
        page.setScene(new Scene(root));
        page.show();
    }

    public static boolean validate(TextField name, TextField stock, TextField price, TextField max, TextField min) {
        boolean valid = true;
        int invValue = 0;
        double priceValue = 0;
        int maxValue = 0;
        int minValue = 0;

        String intRegex = "^-?\\d+";

        validationMessage.delete(0, validationMessage.length());

        try {
            if(!getAction().equalsIgnoreCase("Modify")) {
                if (HomeScreenController.getAllInventory().lookupProduct(name.getText()).size() > 0
                        || HomeScreenController.getAllInventory().lookupPart(name.getText()).size() > 0) {
                    validationMessage.append("Name: Name must be unique!\n");
                    valid = false;
                }
            }
            if (name.getText().trim().isEmpty() || name.getText().length()<3 || name.getText().length()>20){
                validationMessage.append("Name: name cannot be empty, must be between 3 and 20 characters\n");
                valid = false;
            }

            if (!stock.getText().matches(intRegex) || Integer.parseInt(stock.getText().trim()) < 0) {
                validationMessage.append("Inv: Enter a valid integer\n");
                valid = false;
            } else {
                invValue = Integer.parseInt(stock.getText().trim());
            }
            try {
                priceValue = Double.parseDouble(price.getText().trim());
            } catch (Exception e){
                validationMessage.append("Price: Enter a valid number\n");
                valid = false;
            };

            if (!max.getText().matches(intRegex) || Integer.parseInt(max.getText().trim()) < 0
                    || Integer.parseInt(max.getText().trim()) < Integer.parseInt(min.getText().trim())
            )  {
                validationMessage.append("Max: Enter a valid integer\n");
                valid = false;
            } else {
                maxValue = Integer.parseInt(max.getText());
            }

            if (!min.getText().matches(intRegex) || Integer.parseInt(min.getText().trim()) < 0
                    || Integer.parseInt(min.getText().trim()) > Integer.parseInt(max.getText().trim())
            ) {
                validationMessage.append("Min: Enter a valid integer\n");
                valid = false;
            } else {
                minValue = Integer.parseInt(min.getText());
            }
            if (invValue > maxValue || invValue < minValue) {
                validationMessage.append("Inv: Must be between Max and Min\n");
                valid = false;
            } else if (invValue < 0) {
                validationMessage.append("Inv: Must be greater than or equal to 0\n");
                valid = false;
            }
            if (priceValue < 0) {
                validationMessage.append("Price: Must be greater than 0\n");
                valid = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "An error has occurred.");
            alert.setTitle("Error");
            alert.showAndWait();
        }
        return valid;
    }

    public static boolean validateMachineIdOrCompanyName(TextField text, boolean in, boolean out) {
        boolean valid = true;
        if (in && text.getText().length()>6 || in && !text.getText().matches("^-?\\d+")) {
            validationMessage.append("Machine ID: Cannot not be greater than 6\nOR\nCannot Contain Letters!\n");
            valid = false;
        } else if (out && text.getText().trim().isEmpty()) {
            validationMessage.append("Company Name: Company cannot be blank\n");
            valid = false;
        }
        return valid;
    }

    public static void setAction(String action) {
        Utils.action = action;
    }

    public static String getAction() {
        return action;
    }

}
