
import java.util.Scanner;

public class SmartHome2 {
	private static Scanner z = new Scanner(System.in);
	private static Music m1;
	private static Television t1;
	private static Camera c1;
	private static HVAC h1;
	private static Light l1;
	private static Oven o1;
	private static Refrigerator r1;
	private static MotionSensor ms1;

	public static void main(String args[]) {
		int in = 0;
		setupDevices();
		System.out.println("Hello! What can I do for You?");
		printHelpOptions();
		String tempResponse = "";
		while (true) {
			in = z.nextInt();
			z.nextLine();
			if (in == 1) {
//				Light l1 = new Light();
//				l1.LightStatus();
			} else if (in == 2) {
//				Camera c1 = new Camera();
//				c1.CheckCamera();
			} else if (in == 3) {
				System.out.println("What song would you like to play?");
				tempResponse = z.nextLine();
				m1.playMusic(tempResponse);
				System.out.println("Playing Song: " + m1.getSong());
			} else if (in == 4) {
				m1.stopMusic();
			} else if (in == 5) {
//				MotionSensor s1 = new MotionSensor();
//				s1.CheckMotionSensor();
			} else if (in == 6) {
//				t1.TV_ON();
			} else if (in == 7) {
//				Television t1 = new Television();
//				t1.TVoff();
			} else if (in == 8) {
//				Oven o = new Oven();
//				o.lookinOven();
			} else if (in == 9) {
//				Refrigerator re = new Refrigerator();
//				re.lookinRefri();
			} else if (in == 10) {
//				HVAC h = new HVAC();
//				h.lookinHVAC();
			} else if (in == 11) {
//				System.out.println("Shutting down");
				break;
			} else if (in == 12) {
				printHelpOptions();
			}
		}
	}

	private static void printHelpOptions() {
		System.out.println("I will respond to any of the below mentioned commands:");
		String[] options = { ("LightAdjust"), ("CheckCamera"), ("PlayMusic"), ("StopMusic"), ("SensorCheck"),
				("TelevisionOn"), ("TelevisionOff"), ("Ovencheck"), ("OpenRefrigerator"), ("CheckHVAC"),
				("CloseSystem"), ("Help") };
		for (int i = 0; i < options.length; i++) {
			System.out.printf("[%2d]--%s\n", i + 1, options[i]);
		}
	}

	private static void setupDevices() {
		m1 = new Music(state(true), "Living Room");
		t1 = new Television(state(false), "Living Room");
		r1 = new Refrigerator(state(true), "Kitchen");
		c1 = new Camera(state(true), "Outside");
		h1 = new HVAC(state(true), "Outside");
		l1 = new Light(state(false), "Living Room");
		o1 = new Oven(state(false), "Kitchen");
		ms1 = new MotionSensor(state(true), "Outside");
	}

	private static String state(boolean state) {
		return state ? "ON" : "OFF";
	}
}