
public class Oven extends Appliance {

	/**
	 * @param powerStatus
	 * @param room
	 */
	public Oven(String powerStatus, String room) {
		super(powerStatus, room);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Oven [powerStatus=" + getPowerStatus() + ", room=" + getRoom() + "]";
	}

//	private String item;
//	private int t;
//
//	public Oven() {
//		System.out.println("Welcome to the Oven Check");
//	}
//
//	void lookinOven() {
//		checkOven();
//	}

}